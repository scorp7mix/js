<?php

    // CORS
    header("Access-Control-Allow-Origin: *");

	$response = '';

    $records = json_decode(file_get_contents('./records.json'), true);

    if(!empty($_POST) && !empty($_POST['name']) && !empty($_POST['score'])) {

        $candidate = ["name" => $_POST['name'], "score" => (int)$_POST['score']];

        for($i = 1, $l = count($records) + 2; $i < $l; $i++) {
            if((int)$records[$i]['score'] < $candidate['score']) {
                $temp = $records[$i];
                $records[$i] = $candidate;
                $candidate = $temp;
            }
        }

        file_put_contents('./records.json', json_encode($records));
    }

    if(!empty($_POST) && !empty($_POST['searchText'])) {
        $names = [];

        foreach($records as $record) {
            if((false !== strripos($record['name'], $_POST['searchText'])) && (!in_array($record['name'], $names))) {
                $names[] = $record['name'];
            }
        }

        echo json_encode($names);
        die();
    }

    if(!empty($_POST) && !empty($_POST['getRecordsFor'])) {
        foreach($records as $key => $record) {
            if($record['name'] == $_POST['getRecordsFor']) {
                $response .= "<tr><td>" . $key . "</td><td>" . $record['name'] . "</td><td>" . $record['score'] . "</td></tr>";
            }
        }

        echo $response;
        die();
    }

    for($i = 1; $i < 8; $i++) {
        $response .= "<tr><td>" . $i . "</td><td>" . $records[$i]['name'] . "</td><td>" . $records[$i]['score'] . "</td></tr>";
    }
	echo $response;
