Правки:

game.js:
   36      добавлено ajaxSetup
   155     изменено scoresRefresh

onload.js
   62      использование плагина поиска

plugin.js, plugin.css
           сам плагин