// объект игры
var game;

// коллекция кодов используемых клавиш
var keyCodes = {
    'KEY_LEFT': 37,
    'KEY_UP': 38,
    'KEY_RIGHT': 39,
    'KEY_DOWN': 40,
    'SPACE': 32
};

// обработчик нажатия клавиш
function checkKeyDown(e) {
    if(!game) return;
    switch (e.keyCode) {
        case keyCodes['KEY_LEFT']:
            game.setCourse('left');
            break;
        case keyCodes['KEY_UP']:
            game.setCourse('up');
            break;
        case keyCodes['KEY_RIGHT']:
            game.setCourse('right');
            break;
        case keyCodes['KEY_DOWN']:
            game.setCourse('down');
            break;
        case keyCodes['SPACE']:
            game.togglePause();
            break;
    }
}

// точка входа
$(document).ready(function () {

    $("#title").fadeOut(0);

    $(document).on("keydown", checkKeyDown);

    game = new Game('#matrix1', 20, 20, $('#food-count').val(), $('#anti-count').val());
    game.scoresRefresh();

    $('#start-btn').on('click', function() {
        game.reset($('#food-count').val(), $('#anti-count').val());

        $("#title").fadeOut(0);
        $("#alerts, #length").empty();

        $(this).blur();
        $('#save-score').css("display","none");
    }).focus();

    $('#save-score-btn').on('click', function() {
        game.scoresRefresh({name: $('#save-score-name').val(), score: game.score});
        $(this).blur();
        $('#save-score').css("display","none");
        $('#start-btn').focus();
    });

    $('.custom-search-text').on('input', function() {
        $(this).customSearch({
            context: this,
            url: './ajax/records.php',
            data: {searchText: $(this).val()},
            onSelect: function() {
                $.ajax({
                    type: "POST",
                    url: './ajax/records.php',
                    data: {getRecordsFor: $(this).text()},
                    success: function(data) {
                        $('.custom-search-list').css("display","none");
                        $('.custom-search').parent().find("table").html(data);
                    }
                });
            }
        });
    });

});