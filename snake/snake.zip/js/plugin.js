$.fn.customSearch = function(options) {
    $.ajax({
        type: "POST",
        url: options.url,
        data: options.data,
        success: function(data) {
            if(data.length == 0) return;
            var list = $(options.context).parent().find('.custom-search-list');
            list.css("display", "block");
            var ul = list.find("ul").empty();
            for (var i = 0, l = data.length; i < l; i++) {
                var li = $("<li>" + data[i] + "</li>");
                li.on("click", options.onSelect);
                ul.append(li);
            }
        },
        error: function (){},
        dataType: 'json'
    });
};
